# Fifa World Cup ScoreKeeper

Fifa World Cup ScoreKeeper is a Single screeen Score Keeper app, which lets you updates goal scores, shots, shots on target, fouls, yellow and red cards for the final match between France and Croatia during the FIFA World Cup 2018 which held at Russia.

## Using the Fifa World Cup ScoreKeeper App
Start the App

- Update goals, shots, shots on target, fouls, amount of yellow and red cards given by clicking on the various buttons attached to the various TextViews
- Click on the **RESET** button to restart and reset all scores and points awarded 

## Basic Feautures
- One Activity
  + Main Activity
- It contains
  + An Overall layout divided into two columns, one for each team.
  + Score, Shots, Shots on target, fouls, yellow card and red card buttons
  + A Reset button

## Link to download at the App
The apk can be downloaded from [here](https://drive.google.com/open?id=141bTlAGaoS2UExnM-UA-ZmKdXRhE8kYX).

##Special Thanks
- To Google, Andela and Udacity for the opportunity to learn Android development.
- To mentors, facilitators and reviewers tirelessly working at Udacity and Andela helping me learn better and faster.
- To my Android Basics co-learners for their support and assistance